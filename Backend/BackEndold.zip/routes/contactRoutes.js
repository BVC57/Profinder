const express = require('express');
const router = express.Router();
const contactController = require('../controllers/contactController');
const auth = require('../middleware/authMiddleware');
const authorizeRoles = require('../middleware/roleMiddleware');
const ContactSubmission = require('../models/ContactSubmission');

// Contact form submission route (public route)
router.post('/submit', contactController.submitContactForm);

// Get all contact form submissions (super admin only)
router.get('/submissions', auth, authorizeRoles('superadmin'), async (req, res) => {
  try {
    const submissions = await ContactSubmission.find({})
      .sort({ createdAt: -1 });
    
    res.status(200).json({
      success: true,
      count: submissions.length,
      submissions
    });
  } catch (error) {
    console.error('Error fetching contact submissions:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching contact submissions',
      error: error.message
    });
  }
});

// Get a single contact form submission by ID (super admin only)
router.get('/submissions/:id', auth, authorizeRoles('superadmin'), async (req, res) => {
  try {
    const submission = await ContactSubmission.findById(req.params.id);
    
    if (!submission) {
      return res.status(404).json({
        success: false,
        message: 'Contact submission not found'
      });
    }
    
    res.status(200).json({
      success: true,
      submission
    });
  } catch (error) {
    console.error('Error fetching contact submission:', error);
    res.status(500).json({
      success: false,
      message: 'Error fetching contact submission',
      error: error.message
    });
  }
});

// Update contact form submission status (super admin only)
router.patch('/submissions/:id', auth, authorizeRoles('superadmin'), async (req, res) => {
  try {
    const { status, notes } = req.body;
    
    const submission = await ContactSubmission.findById(req.params.id);
    
    if (!submission) {
      return res.status(404).json({
        success: false,
        message: 'Contact submission not found'
      });
    }
    
    if (status) submission.status = status;
    if (notes) submission.notes = notes;
    
    await submission.save();
    
    res.status(200).json({
      success: true,
      message: 'Contact submission updated successfully',
      submission
    });
  } catch (error) {
    console.error('Error updating contact submission:', error);
    res.status(500).json({
      success: false,
      message: 'Error updating contact submission',
      error: error.message
    });
  }
});

// Delete contact form submission (super admin only)
router.delete('/submissions/:id', auth, authorizeRoles('superadmin'), async (req, res) => {
  try {
    const submission = await ContactSubmission.findById(req.params.id);
    
    if (!submission) {
      return res.status(404).json({
        success: false,
        message: 'Contact submission not found'
      });
    }
    
    await ContactSubmission.findByIdAndDelete(req.params.id);
    
    res.status(200).json({
      success: true,
      message: 'Contact submission deleted successfully'
    });
  } catch (error) {
    console.error('Error deleting contact submission:', error);
    res.status(500).json({
      success: false,
      message: 'Error deleting contact submission',
      error: error.message
    });
  }
});

module.exports = router;