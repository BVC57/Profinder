import React from 'react';
import VerifiedAdminList from '../components/VerifiedAdminList';

const VerifiedAdmins = () => {
  return <VerifiedAdminList />;
};

export default VerifiedAdmins;
